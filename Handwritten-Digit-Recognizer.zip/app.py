
from flask import Flask, render_template, request
import os
from predict import predict_digit

app = Flask(__name__)

UPLOAD_FOLDER = "static"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():

    file = request.files["image"]

    filepath = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)

    file.save(filepath)

    digit, confidence = predict_digit(filepath)

    return render_template(
        "index.html",
        prediction=digit,
        confidence=confidence,
        image=filepath
    )

if __name__ == "__main__":
    app.run(debug=True)
