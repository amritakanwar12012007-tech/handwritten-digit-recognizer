# Handwritten Digit Recognizer

A deep learning project developed using TensorFlow and Flask.

## Features

- CNN based digit recognition
- Upload handwritten digit image
- Predict digit with confidence score
- Trained on MNIST dataset

## Technologies

- Python
- TensorFlow
- Flask
- OpenCV
- NumPy
