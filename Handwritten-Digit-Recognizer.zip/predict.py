
import cv2
import numpy as np
from tensorflow.keras.models import load_model

model = load_model("digit_recognizer.keras")

def predict_digit(image_path):

    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    if np.mean(img) > 127:
        img = 255 - img

    img = cv2.resize(img, (28,28))

    img = img.astype("float32") / 255.0

    img = img.reshape(1,28,28,1)

    prediction = model.predict(img)

    digit = int(np.argmax(prediction))

    confidence = float(np.max(prediction) * 100)

    return digit, round(confidence,2)
